CREATE PROCEDURE hah(IN out_count INT(10))
  begin 
select count(*) into out_count from course;
end;
