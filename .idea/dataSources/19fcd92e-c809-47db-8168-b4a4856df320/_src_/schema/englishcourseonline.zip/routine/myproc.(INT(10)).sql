CREATE PROCEDURE myproc(IN p_id INT(10))
  begin
update course set info='666' where courseid = p_id;
end;
